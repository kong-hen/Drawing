-- MySQL dump 10.13  Distrib 5.7.39, for Linux (x86_64)
--
-- Host: localhost    Database: khqt
-- ------------------------------------------------------
-- Server version	5.7.39-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adname` text NOT NULL COMMENT '管理名称',
  `adpass` text NOT NULL COMMENT '管理密码',
  `adhaed` text NOT NULL COMMENT '管理员头像',
  `more` text NOT NULL COMMENT '其他',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','123456','https://vkceyugu.cdn.bspapp.com/VKCEYUGU-e9cc51d7-8d77-4037-8581-1c5289274e0a/b8724698-b65a-4650-bb11-fa720f304dbd.jpg','');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allzy`
--

DROP TABLE IF EXISTS `allzy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allzy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zyfl` text NOT NULL,
  `zykl` text NOT NULL,
  `zyurl` text NOT NULL,
  `zyzt` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allzy`
--

LOCK TABLES `allzy` WRITE;
/*!40000 ALTER TABLE `allzy` DISABLE KEYS */;
INSERT INTO `allzy` VALUES (2,'wallpaper','KongHen','https://vkceyugu.cdn.bspapp.com/VKCEYUGU-e9cc51d7-8d77-4037-8581-1c5289274e0a/c0e77fa2-0a50-463d-b8c5-68dd7a0d24e0.png',1),(3,'wallpaper','KongHen','https://vkceyugu.cdn.bspapp.com/VKCEYUGU-e9cc51d7-8d77-4037-8581-1c5289274e0a/c0e77fa2-0a50-463d-b8c5-68dd7a0d24e0.png',1),(5,'head','KongHen','https://vkceyugu.cdn.bspapp.com/VKCEYUGU-e9cc51d7-8d77-4037-8581-1c5289274e0a/7142762a-0bf3-42e9-83ed-2619ba90c44a.jpg',1),(6,'emoji','KongHen','https://vkceyugu.cdn.bspapp.com/VKCEYUGU-e9cc51d7-8d77-4037-8581-1c5289274e0a/4d672efc-8852-4fc4-b675-a0da5935d382.gif',1),(7,'emoji','KongHen','https://vkceyugu.cdn.bspapp.com/VKCEYUGU-e9cc51d7-8d77-4037-8581-1c5289274e0a/4d672efc-8852-4fc4-b675-a0da5935d382.gif',1),(14,'head','KongHen','https://wq.khkj.xyz/uploads/20221122192727416.jpg',1),(15,'head','KongHen','https://wq.khkj.xyz/uploads/20221122192815649.jpg',1),(16,'head','KongHen','https://wq.khkj.xyz/uploads/20221122192826581.jpg',1),(17,'wallpaper','khkj','https://wq.khkj.xyz/uploads/20221122201439433.png',1),(27,'emoji','khkj','https://wq.khkj.xyz/uploads/20221122203133671.jpg',1);
/*!40000 ALTER TABLE `allzy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xcxpz`
--

DROP TABLE IF EXISTS `xcxpz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xcxpz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pzname` text NOT NULL,
  `appid` text NOT NULL COMMENT '小程序ID',
  `appsecret` text NOT NULL COMMENT '小程序密钥',
  `adjili` text NOT NULL COMMENT '激励广告',
  `advideo` text NOT NULL COMMENT '视频广告',
  `adcp` text NOT NULL COMMENT '插屏广告',
  `adbanner` text NOT NULL COMMENT 'banner广告',
  `adtp` text NOT NULL COMMENT '贴片广告',
  `adys` text NOT NULL COMMENT '原生广告',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xcxpz`
--

LOCK TABLES `xcxpz` WRITE;
/*!40000 ALTER TABLE `xcxpz` DISABLE KEYS */;
INSERT INTO `xcxpz` VALUES (1,'allpz','空痕取图','','https://vkceyugu.cdn.bspapp.com/VKCEYUGUe9cc51d7-8d77-4037-8581-1c5289274e0a/b8724698-b65a-4650-bb11-fa720f304dbd.jpg','搜索提示','','','',''),(2,'wxpz','wx-sxccccfcfecfvdcdc','dcsddddddddddddddddc','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3',''),(3,'dypz','dy-hzkjdiijjn25555','dcefdcbhdshycuhydsc46c65445c45','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3',''),(4,'kspz','ks-12552GJSGH15552','dcsdvyxhuhchbwc465c4648c48','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','adunit-c276d12e0d40d0f3','');
/*!40000 ALTER TABLE `xcxpz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'khqt'
--

--
-- Dumping routines for database 'khqt'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-27 10:48:39
